import torch
class DQNAgent:
    def __init__(self): pass
    def act(self,state): return 0
