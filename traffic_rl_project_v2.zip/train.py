from env import TrafficEnv
from agent import DQNAgent
env=TrafficEnv(); agent=DQNAgent()
