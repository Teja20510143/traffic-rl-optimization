import numpy as np
class TrafficEnv:
    def __init__(self): self.state=np.zeros(4)
    def step(self,action): return self.state,0,False,{}
