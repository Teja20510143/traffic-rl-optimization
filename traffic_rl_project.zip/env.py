class TrafficEnv:
    def step(self, action): pass
