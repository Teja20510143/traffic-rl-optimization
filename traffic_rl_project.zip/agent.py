class DQNAgent:
    def act(self, state): pass
